package com.employee;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.print.attribute.standard.MediaSize.Other;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;

public class Adminregisterform {

	private JFrame frame;
	private JTextField firstname;
	private JTextField lastname;
	private JPasswordField conpass;
	private JPasswordField password;
	private JTextField buisness;
	private JTextField email;
	private JTextField mob;
	private JLabel lblNewLabel_2;
	private JTextField username;
	private JCheckBox male;
	private JCheckBox female;
	private JCheckBox others;
	private static String FirstName;
	//initialize variable
	String Gender;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Adminregisterform window = new Adminregisterform();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Adminregisterform() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(0, 128, 128));
//		application name
		frame.setTitle("Admin Registration");
		
		frame.getContentPane().setForeground(new Color(0, 0, 0));
		frame.setBackground(new Color(128, 255, 128));
		frame.setBounds(50, 70, 900, 500);
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Admin Register Portal");
		lblNewLabel.setForeground(new Color(152, 251, 152));
		lblNewLabel.setFont(new Font("Kalinga", Font.BOLD, 16));
		lblNewLabel.setBounds(89, 26, 207, 23);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("FirstName");
		lblNewLabel_1.setBounds(76, 77, 96, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Gender");
		lblNewLabel_1_1.setBounds(76, 180, 49, 14);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("LastName");
		lblNewLabel_1_2.setBounds(76, 132, 174, 14);
		frame.getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Password");
		lblNewLabel_1_3.setBounds(76, 272, 71, 23);
		frame.getContentPane().add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Confirm Password");
		lblNewLabel_1_4.setBounds(76, 319, 207, 14);
		frame.getContentPane().add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("D.O.B");
		lblNewLabel_1_5.setBounds(473, 77, 35, 14);
		frame.getContentPane().add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Buisness Type");
		lblNewLabel_1_6.setBounds(471, 116, 89, 23);
		frame.getContentPane().add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Email:-");
		lblNewLabel_1_7.setBounds(473, 180, 207, 14);
		frame.getContentPane().add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_8 = new JLabel("Mobile No:-");
		lblNewLabel_1_8.setBounds(473, 212, 184, 14);
		frame.getContentPane().add(lblNewLabel_1_8);
		
		JLabel lblNewLabel_1_9 = new JLabel("Address:-");
		lblNewLabel_1_9.setBounds(473, 248, 207, 14);
		frame.getContentPane().add(lblNewLabel_1_9);
		
		firstname = new JTextField();
		firstname.setBounds(145, 74, 138, 20);
		frame.getContentPane().add(firstname);
		firstname.setColumns(10);
		
		lastname = new JTextField();
		lastname.setBounds(145, 129, 138, 20);
		frame.getContentPane().add(lastname);
		lastname.setColumns(10);
		
		 male = new JCheckBox("Male");
		male.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(male.isSelected())
				{
//					JOptionPane.showMessageDialog(male.getText(), "Male");
					female.setSelected(false);
					others.setSelected(false);
				}
			}
		});
		male.setBounds(145, 176, 65, 23);
		frame.getContentPane().add(male);
		
		female = new JCheckBox("Female");
		female.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(female.isSelected())
				{
//					JOptionPane.showMessageDialog(female, "Female");
					male.setSelected(false);
					others.setSelected(false);
				}
			}
		});
		female.setBounds(212, 176, 71, 23);
		frame.getContentPane().add(female);
		
		 others = new JCheckBox("Others");
		 others.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		if(others.isSelected())
				{
//					JOptionPane.showMessageDialog(others, "Others");
					female.setSelected(false);
					male.setSelected(false);
				}
		 	}
		 });
		others.setBounds(286, 176, 71, 23);
		frame.getContentPane().add(others);
		
		conpass = new JPasswordField();
		conpass.setBounds(186, 313, 128, 20);
		frame.getContentPane().add(conpass);
		
		password = new JPasswordField();
		password.setBounds(157, 275, 138, 20);
		frame.getContentPane().add(password);
		
		buisness = new JTextField();
		buisness.setBounds(563, 117, 146, 20);
		frame.getContentPane().add(buisness);
		buisness.setColumns(10);
		
		email = new JTextField();
		email.setBounds(522, 177, 191, 20);
		frame.getContentPane().add(email);
		email.setColumns(10);
		
		mob = new JTextField();
		mob.setBounds(546, 209, 140, 20);
		frame.getContentPane().add(mob);
		mob.setColumns(10);
		
		JTextArea address = new JTextArea();
		address.setBounds(471, 273, 207, 60);
		frame.getContentPane().add(address);
		
		JButton regbtn = new JButton("Register");
		regbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(regbtn, "Register Successful");
//				db part && get and set data
				String FirstName=firstname.getText();
				String LastName=lastname.getText();
				 Gender= "";
				 if(male.isSelected())
					 {
					Gender= male.getText();
					 }
				 else if(female.isSelected())
				 {
				 Gender=female.getText();
				 }
				 else
				 {
				 Gender=others.getText();
				 }
				 String UserName=username.getText();
				String Password=password.getText();
				String Conpass=conpass.getText();
				String Buisness=buisness.getText();
				String Email=email.getText();
				String Mob=mob.getText();
				String Address=address.getText();
				if(FirstName.equals("")|| LastName.equals("")|| Gender.equals("")|| UserName.equals("")|| Password.equals("")|| Conpass.equals("")|| Buisness.equals("")|| Email.equals("")|| Mob.equals("")||
						Address.equals("")) {
					JOptionPane.showMessageDialog(null, "Please fill in all fields.");
				}
				else if(Password.equals(Conpass))
				{
							JOptionPane.showMessageDialog(conpass,"Register Successful");
				}
						else {
							JOptionPane.showMessageDialog(null, "Password did not matched.Please try again!");
						}
				
				int len=Mob.length();
				if(len!=10)
				{
					JOptionPane.showMessageDialog(mob, "Enter a Valid Number");
				}
				
				
//				insert adminregistration into database
				Connection con=emp_Dao.Datac();
				try {
					String sql="insert into adminreg values('"+ FirstName +"','"+ LastName +"','"+ UserName +"',"
							+ "'"+ Password +"','"+ Buisness +"','"+ Email +"','"+ Mob +"','"+ Address +"','"+ Gender +"',)";
						Statement stm=con.createStatement();
					
					
					//execute
					 stm.executeQuery(sql);
					
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				finally {
					try {
						con.close();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
			}
			
		});
		regbtn.setForeground(new Color(128, 255, 128));
		regbtn.setBackground(new Color(240, 240, 240));
		regbtn.setBounds(385, 406, 89, 23);
		frame.getContentPane().add(regbtn);
		
		JComboBox dt = new JComboBox();
		dt.addItem("1");
		dt.addItem("2");
		dt.addItem("3");
		dt.addItem("4");
		dt.addItem("5");
		dt.addItem("6");
		dt.addItem("7");
		dt.addItem("8");
		dt.addItem("9");
		dt.addItem("10");
		dt.addItem("11");
		dt.addItem("12");
		dt.addItem("13");
		dt.addItem("14");
		dt.addItem("15");
		dt.addItem("16");
		dt.addItem("17");
		dt.addItem("18");
		dt.addItem("19");
		dt.addItem("20");
		dt.addItem("21");
		dt.addItem("22");
		dt.addItem("23");
		dt.addItem("24");
		dt.addItem("25");
		dt.addItem("26");
		dt.addItem("27");
		dt.addItem("28");
		dt.addItem("29");
		dt.addItem("30");
		dt.addItem("31");
		dt.setBounds(603, 73, 49, 22);
		frame.getContentPane().add(dt);
		
		JComboBox month = new JComboBox();
//		month
		month.addItem("Jan");
		month.addItem("Feb");
		month.addItem("Mar");
		month.addItem("Apr");
		month.addItem("May");
		month.addItem("Jun");
		month.addItem("Jul");
		month.addItem("Aug");
		month.addItem("Sep");
		month.addItem("Oct");
		month.addItem("Nov");
		month.addItem("Dec");
	
		
		month.setBounds(662, 73, 59, 22);
		frame.getContentPane().add(month);
		
		JComboBox yr = new JComboBox();
		yr.addItem("2023");
		yr.addItem("2022");
		yr.addItem("2021");
		yr.addItem("2020");
		yr.addItem("2019");
		yr.addItem("2018");
		yr.addItem("2017");
		yr.addItem("2016");
		yr.addItem("2015");
		yr.addItem("2014");
		yr.addItem("2013");
		yr.addItem("2012");
		yr.addItem("2011");
		yr.addItem("2010");
		yr.addItem("2009");
		yr.addItem("2008");
		yr.addItem("2007");
		yr.addItem("2006");
		yr.addItem("2005");
		yr.addItem("2004");
		yr.addItem("2003");
		yr.addItem("2002");
		yr.addItem("2001");
		yr.addItem("2000");
		yr.addItem("1999");
		yr.addItem("1998");
		yr.addItem("1997");
		yr.addItem("1996");
		yr.addItem("1995");
		yr.addItem("1994");
		yr.addItem("1993");
		yr.addItem("1992");
		yr.addItem("1991");
		yr.addItem("1990");
		yr.addItem("1989");
		yr.addItem("1988");
		yr.addItem("1987");
		yr.addItem("1986");
		yr.addActionListener(new ActionListener() {
		});
		yr.setBounds(522, 73, 71, 22);
		frame.getContentPane().add(yr);
		
		lblNewLabel_2 = new JLabel();
		lblNewLabel_2.setIcon(new ImageIcon("D:/Softwear/EMS/src/pic2.png"));
		lblNewLabel_2.setBounds(45, 11, 40, 40);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Username");
		lblNewLabel_3.setBounds(76, 223, 71, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		username = new JTextField();
		username.setBounds(156, 220, 140, 20);
		frame.getContentPane().add(username);
		username.setColumns(10);
	}
}
