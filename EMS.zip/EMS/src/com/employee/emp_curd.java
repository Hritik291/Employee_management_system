package com.employee;
package com.employee;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class emp_curd {

	public static void adminregdb() throws SQLException
	{
		Connection con=emp_Dao.Datac();
		try {
			String sql="insert into adminreg values('"+ FirstName +"','"+ LastName +\"','\"+ FirstName +\"','\"+ FirstName +\"',)";
			PreparedStatement ps=con.prepareStatement(sql);
			
			
			//execute
			 ps.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			con.close();
		}
	}

}
